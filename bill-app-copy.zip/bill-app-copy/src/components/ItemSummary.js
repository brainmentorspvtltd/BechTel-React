import { useSelector } from "react-redux"

export const ItemSummary = ()=>{
    const items = useSelector(state=>state.items);
    const billTotal = (items)=>{
        return items.reduce((old, current)=>old+parseInt(current.price), 0);
    }
    return (<>
        <p>Total Bill is {items && items.length>0?billTotal(items):0} </p>
    </>)
}