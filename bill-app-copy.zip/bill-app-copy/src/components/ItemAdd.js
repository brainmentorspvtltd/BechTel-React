import { useRef } from "react"
import { ActionCreator } from "../redux/async-action-creator";
import { itemAction } from "../redux/item-action";
import { store } from "../redux/store";



export const ItemAdd = ()=>{
    const itemcode = useRef('');
    const itemName = useRef('');
    const itemPrice = useRef('');
    const itemAdd = ()=>{
        const itemObject = {'id':itemcode.current.value, 'name':itemName.current.value,'price':itemPrice.current.value};
        const action = itemAction('ADD',itemObject);
        store.dispatch(action); // Sync Dispatch
        asyncCall(); // Async Dispatch
    }

    // Async Dispatch

    const asyncCall = ()=>{
        store.dispatch(ActionCreator('VIEW',100,200));
    }
    
    return (<>
        <div className = 'form-group'>
        <label>ItemCode</label>
        <input ref={itemcode} type='text' placeholder="Type Item Code"/>
        <label>Name</label>
        <input ref={itemName} type='text' placeholder="Type Item Name"/>
        <label>Price</label>
        <input ref={itemPrice} type='text' placeholder="Type Item Price"/>
        </div>
        <div>
            <button onClick={itemAdd}>Add</button>
            
        </div>
    </>)
}