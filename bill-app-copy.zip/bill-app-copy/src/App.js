import logo from './logo.svg';
import './App.css';
import { BillingHome } from './pages/BiilingHome';

function App() {
  return (
   <BillingHome/>
  );
}

export default App;
