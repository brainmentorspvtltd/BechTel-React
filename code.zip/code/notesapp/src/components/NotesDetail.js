import React,{useRef, useContext} from 'react'
import { NotesContext } from '../context/NotesContext';
export const NotesDetail = ()=>{
    const noteName = useRef();
    const context = useContext(NotesContext);
    const addNote = ()=>{
        const val = noteName.current.value;
        context.addNote({'name':val});
        
    }
    return <> 
    <div className='form-group'>
        <label>Name</label>
        <input ref={noteName} className='form-control' type='text' placeholder='Type Notes Here'/>
    </div>
    <div>
        <button onClick= {addNote}>Add a Note</button>
    </div>
    </>
}