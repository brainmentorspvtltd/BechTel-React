import {useContext} from 'react';
import { NotesContext } from '../context/NotesContext';
export const NotesList = ()=>{
    //useContext()
    return <>
           <NotesContext.Consumer>
            {(value)=>
                value.notes.map(note=><p>{note.name}</p>)
            }
            </NotesContext.Consumer> 
    </>
}