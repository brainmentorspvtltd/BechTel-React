import React from 'react';
export const NotesContext = React.createContext({notes:[], noteCount:0, addNote:(note)=>null});