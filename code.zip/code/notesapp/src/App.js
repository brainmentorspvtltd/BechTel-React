import logo from './logo.svg';
import './App.css';
import { NotesApp } from './pages/NotesApp';

function App() {
  return (
    <NotesApp/>
  );
}

export default App;
