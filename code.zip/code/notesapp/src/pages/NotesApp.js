import { NotesDetail } from "../components/NotesDetail"
import { NotesList } from "../components/NotesList"
import { NotesContext } from "../context/NotesContext"
import {useState} from 'react';

export const NotesApp = ()=>{
    const [notes, setNotes] = useState([]);
    const addNote = (noteObject)=>{
        const clone = [...notes];
        clone.push(noteObject);
        setNotes(clone);
    }
    return (<>
    <NotesContext.Provider value={{notes:notes, noteCount:notes.length,addNote: addNote}}>
    <NotesDetail/>
    <hr/>
    <NotesList/>
    </NotesContext.Provider>
    </>)
}