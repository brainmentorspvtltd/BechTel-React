
import React from 'react';
const List = (props) => {
    console.log('List Props is ',props);
  return <>{props.data.map((e,index)=><img key={index} src={e.images.original.url}/>)}</>
};
export default List;

/*
When is it safe to use index as key in a list?
Data is static.
When you know reordering of lists: Sorting, Filtering is not going to happen.
In the absence of an id.
SUMMARY
Always prefer using a unique id as value for the key attribute in a list and avoid using index.
Using index might result in performance issues and data binding issues in case reordering in the form of sorting, filtering might happen.
*/