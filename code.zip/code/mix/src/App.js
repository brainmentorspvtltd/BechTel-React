import logo from './logo.svg';
import './App.css';
import { HocExample } from './HocExample';
import { HookExample } from './components/HookExample';

function App() {
  return (
   <HookExample/>
  );
}

export default App;
