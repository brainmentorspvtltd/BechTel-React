export const Loading = (WrappedComponent)=>{
    const newComponent = ({isLoading , ...props})=>{
        console.log('New Component Called ', isLoading, props);
        if(!isLoading){
            return <WrappedComponent {...props} />;
        }
        return <p>Loading....</p>
    };
    return newComponent;
}