import React from 'react'
import {useState, useEffect, useRef} from 'react';
class A{
    constructor(){
        this.state = {counter : 0}
    }
}
export const HookExample = ()=>{
    const inputElement = useRef();
    const [counter , setCounter] = useState(0);
    const [employee , setEmployee] = useState([]);
    useEffect(() => {
        // Life Cycle
        // Mounting

        // FireBase Connection Code
        // LocalStorage SessionStorage
       
    },[]);

    useEffect(() => {
        // Life Cycle
        // Updation
       
    });
    useEffect(() => {
        // Life Cycle
        // UnMountng
       return function(){

       }
    },[x,y]);
    useEffect(() => {
        console.log("API CALL ");
        // Life Cycle
        // UnMountng
       return function(){
            // FireBase Connection Close 
            // Clean up , LocalStorage
       }
    },[]);


    
    const plus = ()=>{
       
       // counter++; // counter = counter + 1;
        //setCounter(counter);
        setCounter(counter + 1); // Immutable Way
        const clone = [...employee];
        clone.push({id:1001, name:'Ram'});
        setEmployee(clone);
        // setCustomer(clone);
        // setOrder(clone); // Render Here
    }
    const apiCall = async ()=>{
        try{
        const res = await fetch(URL);
        const result2 = await res.json();
        // setResult(result2);
        // setAnotherResult(result2);
        }
        catch(err){

        }

    }
    const addEmployee = ()=>{
        const clone = [...employee];
        clone.push({id:1001, name:'Ram'});
        setEmployee(clone);
    }
    const displayName =()=>{
        const val = inputElement.current.value;
        console.log('Value is ',val);
    }
    console.log('I am Render Call');
    return (React.createElement('p',null, React.createElement('span', null, 'Hello React')));
    // return (<>
    // <p>Hook Demo</p>
    // <p> {counter}</p>
    // <input ref={inputElement}  type = 'text' placeholder='Type Name Here'/>
    // <button onClick={displayName}>Display Name</button>
    // <button onClick = {plus}>+</button>
    // <button onClick = {addEmployee}>Add Emp</button>
    // {employee.map((emp,index)=><p key={index}>{emp.id} {emp.name}</p>)}
    // </>)
}