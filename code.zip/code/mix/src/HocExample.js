import React, {useEffect, useState} from 'react';
import { Loading } from './hoc/Loading';
import List from './List';
const ListWithLoading = Loading(List);
export const HocExample = ()=>{
    const [data, setData] = useState({isLoading:true, result:null});
    useEffect( ()=>{
        fetchData();
        
            
    },[]);
    const fetchData = async ()=>{
        try{
        const result =await fetch('https://api.giphy.com/v1/gifs/search?api_key=vFRSFWo6g7vJ7ZAjt3DMDolU52ORTxwH&q=Iron%20man&limit=5');
        const jsondata = await result.json();
        console.log('Data is ', jsondata);
        setData({isLoading:false, result:jsondata.data});
        
    }
        catch(err){
            console.log('Error in Fetch Data ', err);
        }
    }
    console.log('Set State ', data);
    return <ListWithLoading isLoading={data.isLoading} data = {data.result}/>
}