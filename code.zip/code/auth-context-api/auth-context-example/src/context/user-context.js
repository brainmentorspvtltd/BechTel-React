import {createContext, useReducer, useState} from 'react';
import { userReducer } from '../reducers/user-reducer';
export const UserContext = createContext({currentUser:null, setCurrentUser:()=>null});
// UserContext.Provider and UserContext.Consumer
// Old Way
// export const UserProvider = ({children})=>{
//     const [currentUser, setCurrentUser] = useState(null);
//     const value = {currentUser, setCurrentUser};
//     return <UserContext.Provider value = {value}>{children}</UserContext.Provider>;
// }

// New Way with Reducer , Action
 const initState= {currentUser:null};
export const UserProvider = ({children})=>{
    const [{currentUser}, dispatch] = useReducer(userReducer, initState);
    const setCurrentUser = (user)=>{
        dispatch({type:'LOGIN', payload: user}); // Dispatch an Action
    }
    const value = {currentUser, setCurrentUser};
    return <UserContext.Provider value = {value}>{children}</UserContext.Provider>;
}