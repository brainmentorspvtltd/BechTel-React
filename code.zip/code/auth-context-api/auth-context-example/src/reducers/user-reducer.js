export const userReducer = (state={}, action)=>{
    const {type, payload} = action;
    if(type ==='LOGIN'){
        console.log('Inside Login Reducer ', type, payload);
        return {currentUser: payload, isLoggedIn : true};
    }
    else if (type==='LOGOUT'){
        return {currentUser: payload, isLoggedIn : false};
    }
    return state;
}