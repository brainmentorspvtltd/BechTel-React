import { useContext } from "react"
import { UserContext } from "../context/user-context"

export const Profile = ()=>{
   const {currentUser} =  useContext(UserContext);
    return (<h1>Welcome {currentUser.userid}</h1>)
}