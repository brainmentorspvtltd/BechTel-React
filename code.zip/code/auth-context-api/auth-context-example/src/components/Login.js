import { useContext, useRef } from "react"
import { UserContext } from "../context/user-context";

export const Login = ()=>{
    const userid = useRef('');
    const password = useRef('');
    const {setCurrentUser} = useContext(UserContext); //{currentUser:null, setCurrentUser:()=>null}
    const doLogin = ()=>{
        const userIdValue = userid.current.value;
        const passwordValue = password.current.value;
        setCurrentUser({'userid':userIdValue, 'password':passwordValue});
    }
    const doReset = ()=>{
        userid.current.value = "";
         password.current.value = "";
        
    }
    return (
    <>
    <div className = 'form-group'>
        <label>Userid</label>
        <input className="form-control" type='text' ref={userid} placeholder="Type Userid Here"/>
        
    </div>
    <div className = 'form-group'>
        <input className="form-control" type='text' ref={password} placeholder="Type Password Here"/>
    </div>
    <div>
        <button onClick = {doLogin}>Login</button>
        <button onClick = {doReset}>Reset</button>
        </div>    
    </>
    )
}