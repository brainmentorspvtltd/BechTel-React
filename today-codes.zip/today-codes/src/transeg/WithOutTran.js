import {useState} from 'react';
import ListComponent from './ListComponent';
const largeList = [...new Array(20000).keys()];
export const WithOutTrans = ()=>{
    const [name, setName] = useState("")
    const [list, setList] = useState(largeList)
  
    function handleChange(e) {
      setName(e.target.value)
      setList(largeList.filter(item => item.toString().startsWith(e.target.value)))
    }
  
    return <>
      <input type="text" value={name} onChange={handleChange} />
      {list.map(item => <ListComponent key={item} item={item} />)}
    </>
  }