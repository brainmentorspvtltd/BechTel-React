import {useState} from 'react';
import ListComponent from './ListComponent';
import {useTransition} from 'react';
const largeList = [...new Array(20000).keys()];
export const WithTrans = ()=>{
    const [name, setName] = useState("");
    const [list, setList] = useState(largeList);
    // he isPending variable simply returns true while the code inside the
    // startTransition hook is running. Essentially, this variable is 
    //true when the slow state update is running and false when
    // it is finished running
    const [isPending, startTransition] = useTransition(); // Adding useTransition
    function handleChange(e) {
      setName(e.target.value); // Setting the name value
      /*
      The startTransition function takes a single callback and this callback
       just contains all the code related to the slow state update 
       including the setting of the state.
      */
      startTransition(() => {
      setList(largeList.filter(item => item.toString().startsWith(e.target.value)));
      });
      /*
      we are wrapping setList in our startTransition function 
      which tells React that our setList state update is of low importance. 
      This means that as soon as all of our normal state updates 
      are finished that the component should rerender even if this slow state
       update is not finished. Also, if a user interacts with your application, 
       such as clicking a button or typing in an input, those interactions will 
       take higher priority than the code in the startTransition function.
      */
    }
  
    return <>
      <input type="text" value={name} onChange={handleChange} />
      {isPending?"LOADING ....":""}
      {list.map(item => <ListComponent key={item} item={item} />)}
    </>
  }