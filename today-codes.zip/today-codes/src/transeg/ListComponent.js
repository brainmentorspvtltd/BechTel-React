import React from 'react'

const ListComponent = ({item}) => {
  return (
    <div>{item}</div>
  )
}

export default ListComponent;