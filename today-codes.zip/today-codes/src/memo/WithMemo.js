import React, { useState } from 'react';
import {useMemo} from 'react';
const expensiveFunction = (inputValue) => {
  
  
  for(let i =1; i<=100000; i++){
    for(let j = 1;j<50000; j++){

    }
  }
    
  let expensiveValue = inputValue ** 3;
  return expensiveValue;
};

export const WithMemo = ({ something }) => {
  const [inputValue, setInputValue] = useState(9);
  const [count, setCount] = useState(0);
  const plus = ()=>{
    setCount(count + 1);
  }
  const inc = ()=>{
    setInputValue(inputValue+1);
  }
  const expensiveValue = useMemo(
    () => expensiveFunction(inputValue), 
    [ inputValue ]
  );

  return <>
  <button onClick = {plus}>Plus</button>
  <button onClick = {inc}>Memo Plus</button>
  <p>Count is {count}</p>
  <h1>Hello {expensiveValue}</h1></>;
};

