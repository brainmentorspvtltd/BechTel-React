import React, { useState } from 'react';

const expensiveFunction = (inputValue) => {
  
  
  for(let i =1; i<=100000; i++){
    for(let j = 1;j<50000; j++){

    }
  }
    
  let expensiveValue = inputValue ** 3;
  return expensiveValue;
};

export const WithOutMemo = ({ something }) => {
  const [inputValue, setInputValue] = useState(9);
  const expensiveValue = expensiveFunction(inputValue);
  return <h1>Hello {expensiveValue}</h1>;
};

