import React from 'react'
import {useDeferredValue} from 'react';
const ListComponent = ({list}) => {
    const deferredList = useDeferredValue(list);
  return (
    <>
    {deferredList.map(item => <div key={item}>{item}</div>)}
    </>
  )
}

export default ListComponent;