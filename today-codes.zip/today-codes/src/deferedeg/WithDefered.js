import {useState} from 'react';
import ListComponent from './ListComponent';

const largeList = [...new Array(20000).keys()];
export const WithDefer = ()=>{
    const [name, setName] = useState("");
    const [list, setList] = useState(largeList);
    
    function handleChange(e) {
      setName(e.target.value); // Setting the name value
     
      
      setList(largeList.filter(item => item.toString().startsWith(e.target.value)));
      
      
    }
  
    return <>
      <input type="text" value={name} onChange={handleChange} />
      
      <ListComponent list = {list}/>
    </>
  }