import logo from './logo.svg';
import './App.css';
import { WithOutTrans } from './transeg/WithOutTran';
import { WithTrans } from './transeg/WithTrans';
import { WithDefer } from './deferedeg/WithDefered';
import { WithOutMemo } from './memo/WithOutMemo';
import { WithMemo } from './memo/WithMemo';
import Consume from './customhooks/Consume';

/*
<WithOutTrans/> Behave
As you can see in this example when you try to type into the input box it is 
really slow and takes about a second to update the input box. 
This is because rendering and processing the list takes so long. 
This is where useTransition comes in.
*/
function App() {
  return (
    <>
      {/* <WithOutTrans/> */}
      

      {/* <WithTrans/> */}

      {/* <WithDefer/> */}
      {/* <WithOutMemo/> */}
      <WithMemo/>
      {/* <Consume/> */}
    </>
  );
}

export default App;

/*
<WithTrans/> Behave
You can see that our input updates immediately when you type,
 but the actual list itself does not update until later. 
 While the list is updating the text Loading... renders and then once the list 
 finishes loading is renders the list.
*/

