import React from 'react'
import {useState, useRef} from 'react';
import {useFetch} from './fetch-hook';
const Consume = () => {
    const [query, setQuery] = useState('');
    const { status, data } = useFetch(query);
    const txt = useRef('');
    const doSearch = ()=>{
        setQuery(txt.current.value);
    }
  return (
    <div>
        
        <input ref={txt} type='text'  placeholder='Type Image Name to Search'/>
        <button onClick={doSearch}>Search It </button>
        <hr/>
        {data.map((e,index)=><img key={index} src={e.images.original.url}/>)}


    </div>
  )
}

export default Consume