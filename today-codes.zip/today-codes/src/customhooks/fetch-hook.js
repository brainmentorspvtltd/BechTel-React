import {useState, useEffect} from 'react';
export const useFetch = (query) => {
    const [status, setStatus] = useState('idle');
    const [data, setData] = useState([]);

    useEffect(() => {
        console.log('Query is ', query);
        if (!query) {
            query = "Iron man";
        }

        const fetchData = async () => {
            setStatus('fetching the images');
            const response = await fetch(
                `https://api.giphy.com/v1/gifs/search?api_key=vFRSFWo6g7vJ7ZAjt3DMDolU52ORTxwH&q=${query}&limit=5`
            );
            const result = await response.json();
            setData(result.data);
            setStatus('Done');
        };

        fetchData();
    }, [query]);

    return { status, data };
};
